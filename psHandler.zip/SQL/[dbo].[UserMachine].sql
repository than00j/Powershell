USE [psHandlerInv]
GO
/****** Object:  Table [dbo].[UserMachine]    Script Date: 10/16/2013 15:13:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserMachine](
	[userName] nvarchar(100) NOT NULL,
	[siteName] nvarchar(10) NOT NULL,
	[domainName] nvarchar(100)NOT NULL,
	[machineID] [int] NOT NULL,
	[lastLogin] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL)






/* OLD OLD
USE [psHandler]
GO

/****** Object:  Table [dbo].[UserMachine]    Script Date: 06-10-2013 18:10:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserMachine](
	[userMachineID] [int] IDENTITY(1,1) NOT NULL,
	[userID] [int] NOT NULL,
	[machineID] [int] NOT NULL,
	[lastLogin] [nvarchar](50) NULL,
 CONSTRAINT [PK_UserMachine] PRIMARY KEY CLUSTERED 
(
	[userMachineID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO */


