USE [psHandler]
/*DROP TABLE [dbo].[Policies]*/
GO



/****** Object:  Table [dbo].[Policies]    Script Date: 06-10-2013 16:15:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Policies](
	[policyID] [int] IDENTITY(1,1) NOT NULL,
	[roleID] [int] NOT NULL,
	[policyName] [nvarchar](100) NOT NULL,
	[policyObject] [varchar](10) NOT NULL,
	[policyDomain] [varchar](10) NOT NULL,
	[policySite] [varchar](10) NULL,
	[policyGUID] [nvarchar](50) NULL,
	[policyPackage] [nvarchar](500) NOT NULL,
	[policyArgs] [nvarchar](max) NULL,
	[policyAction] [nvarchar](20) NOT NULL,
	[policyAppliesTo] [nvarchar](max) NOT NULL,
	[policyCreatedBy] [nvarchar](50) NOT NULL,
	[policyCreatedDate] [nvarchar](20) NOT NULL,
	[policyModifiedBy] [nvarchar](50) NOT NULL,
	[policyModifiedDate] [nvarchar](20) NOT NULL,
	[comments] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_Policies] PRIMARY KEY CLUSTERED 
(
	[policyID] ASC,
	[roleID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

ALTER TABLE [dbo].[Policies]  WITH CHECK ADD  CONSTRAINT [Policies_Roles_FK] FOREIGN KEY([roleID])
REFERENCES [dbo].[Roles] ([roleID])
GO

ALTER TABLE [dbo].[Policies] CHECK CONSTRAINT [Policies_Roles_FK]
GO

SET ANSI_PADDING OFF
GO


