USE [psHandler]
GO

/****** Object:  Table [dbo].[PolicyStatus]    Script Date: 06-10-2013 16:55:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PolicyStatus](
	[pID] [int] IDENTITY(1,1) NOT NULL,
	[policyName] [nvarchar](100) NOT NULL,
	[policyObject] [nvarchar](10) NOT NULL,
	[objectID] [int] NOT NULL,
	[policyApplied] [nchar](10) NOT NULL,
	[policyComments] [nvarchar](max) NULL,
	[policyApplyON] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_PolicyStatus] PRIMARY KEY NONCLUSTERED 
(
	[pID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO


