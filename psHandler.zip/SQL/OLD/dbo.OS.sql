USE [psHandler]
GO

/****** Object:  Table [dbo].[OS]    Script Date: 16-09-2013 16:09:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[OS](
	[osID] [nvarchar](20) NOT NULL,
	[osName] [nvarchar](100) NULL,
	[majorVersion] [int] NOT NULL,
	[minorVersion] [int] NOT NULL,
	[buildNumber] [int] NOT NULL,
	[servicePackName] [nvarchar](50) NULL,
	[servicePackMajor] [int] NULL,
	[servicePackMinor] [int] NULL,
	[csdVersion] [nvarchar](50) NULL,
	[productType] [int] NULL,
	[suite] [int] NULL,
	[publishedDate] [datetime] NOT NULL,
 CONSTRAINT [OS_PK] PRIMARY KEY NONCLUSTERED 
(
	[osID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[osID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[OS] ADD  CONSTRAINT [DF_OS_osName]  DEFAULT ('') FOR [osName]
GO

ALTER TABLE [dbo].[OS] ADD  CONSTRAINT [DF_OS_majorVersion]  DEFAULT ((0)) FOR [majorVersion]
GO

ALTER TABLE [dbo].[OS] ADD  CONSTRAINT [DF_OS_minorVersion]  DEFAULT ((0)) FOR [minorVersion]
GO

ALTER TABLE [dbo].[OS] ADD  CONSTRAINT [DF_OS_buildNumber]  DEFAULT ((0)) FOR [buildNumber]
GO

ALTER TABLE [dbo].[OS] ADD  CONSTRAINT [DF_OS_servicePackMajor]  DEFAULT ((0)) FOR [servicePackMajor]
GO

ALTER TABLE [dbo].[OS] ADD  CONSTRAINT [DF_OS_servicePackMinor]  DEFAULT ((0)) FOR [servicePackMinor]
GO

ALTER TABLE [dbo].[OS] ADD  CONSTRAINT [DF_OS_csdVersion]  DEFAULT ('') FOR [csdVersion]
GO

ALTER TABLE [dbo].[OS] ADD  CONSTRAINT [DF_OS_productType]  DEFAULT ((0)) FOR [productType]
GO

ALTER TABLE [dbo].[OS] ADD  CONSTRAINT [DF_OS_suite]  DEFAULT ((0)) FOR [suite]
GO

ALTER TABLE [dbo].[OS] ADD  CONSTRAINT [DF_OS_publishedDate]  DEFAULT (getdate()) FOR [publishedDate]
GO


