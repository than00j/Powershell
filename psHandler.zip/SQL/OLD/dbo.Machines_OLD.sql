USE [psHandler]
/*DROP TABLE dbo.machines*/

GO

/****** Object:  Table [dbo].[Machines]    Script Date: 16-09-2013 16:24:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Machines](
	[machineID] [nvarchar](20) NOT NULL,
	[osID] [nvarchar](20) NOT NULL,
	[macAddress] [nvarchar](100) NOT NULL,
	[ipAddress] [nvarchar](100) NOT NULL,
	[servicePackMinor] [int] NULL,
	[machineName] [nvarchar](100) NULL,
	[domainID] [int] NOT NULL,
	[windowsDirectory] [nvarchar](100) NULL,
	[systemDirectory] [nvarchar](100) NULL,
	[ram] [numeric](20, 1) NOT NULL,
	[pageFile] [numeric](20, 1) NOT NULL,
	[virtualMem] [numeric](20, 1) NOT NULL,
	[assetTag] [nvarchar](260) NULL,
	[chassisSerialNumber] [nvarchar](260) NULL,
	[chassisVendorName] [nvarchar](260) NULL,
	[processorVendorName] [nvarchar](260) NOT NULL,
	[processorName] [nvarchar](50) NOT NULL,
	[clockSpeed] [int] NOT NULL,
	[processorArchitecture] [nvarchar](128) NOT NULL,
 CONSTRAINT [Machines_PK] PRIMARY KEY NONCLUSTERED 
(
	[machineID] ASC,
	[osID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Machines] ADD  CONSTRAINT [DF_Machines_machineName]  DEFAULT ('') FOR [machineName]
GO

ALTER TABLE [dbo].[Machines] ADD  CONSTRAINT [DF_Machines_domainID]  DEFAULT ('') FOR [domainID]
GO

ALTER TABLE [dbo].[Machines] ADD  CONSTRAINT [DF_Machines_windowsDirectory]  DEFAULT ('') FOR [windowsDirectory]
GO

ALTER TABLE [dbo].[Machines] ADD  CONSTRAINT [DF_Machines_systemDirectory]  DEFAULT ('') FOR [systemDirectory]
GO

ALTER TABLE [dbo].[Machines] ADD  CONSTRAINT [DF_Machines_assetTag]  DEFAULT ('') FOR [assetTag]
GO

ALTER TABLE [dbo].[Machines] ADD  CONSTRAINT [DF_Machines_chassisSerialNumber]  DEFAULT ('') FOR [chassisSerialNumber]
GO

ALTER TABLE [dbo].[Machines] ADD  CONSTRAINT [DF_Machines_chassisVendorName]  DEFAULT ('') FOR [chassisVendorName]
GO

ALTER TABLE [dbo].[Machines] ADD  CONSTRAINT [DF_Machines_processorVendorName]  DEFAULT ('') FOR [processorVendorName]
GO

ALTER TABLE [dbo].[Machines] ADD  CONSTRAINT [DF_Machines_processorName]  DEFAULT ('') FOR [processorName]
GO

ALTER TABLE [dbo].[Machines]  WITH CHECK ADD  CONSTRAINT [Machines_OS_FK] FOREIGN KEY([osID])
REFERENCES [dbo].[OS] ([osID])
GO

ALTER TABLE [dbo].[Machines] CHECK CONSTRAINT [Machines_OS_FK]
GO


