USE [psHandler]
/*DROP TABLE dbo.UserMachine*/
GO

/****** Object:  Table [dbo].[UserMachine]    Script Date: 16-09-2013 16:40:02 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserMachine](
	[userMachineID] [int] IDENTITY(1,1) NOT NULL,
	[userID] [int] NOT NULL,
	[machineID] [int] NOT NULL,
	[lastLogin] [nvarchar](50) NULL
 CONSTRAINT [UserMachine_PK] PRIMARY KEY NONCLUSTERED 
(
	[userMachineID] ASC,
	[userID] ASC,
	[machineID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[UserMachine]  WITH CHECK ADD  CONSTRAINT [UserMachine_User_FK] FOREIGN KEY([userID])
REFERENCES [dbo].[Users] ([userID])
GO

ALTER TABLE [dbo].[UserMachine] CHECK CONSTRAINT [UserMachine_User_FK]
GO

ALTER TABLE [dbo].[UserMachine]  WITH CHECK ADD  CONSTRAINT [UserMachine_Machine_FK] FOREIGN KEY([machineID])
REFERENCES [dbo].[Machines] ([machineID])
GO

ALTER TABLE [dbo].[UserMachine] CHECK CONSTRAINT [UserMachine_Machine_FK]
GO





