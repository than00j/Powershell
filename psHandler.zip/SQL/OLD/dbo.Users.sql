USE [psHandler]
GO

/****** Object:  Table [dbo].[Users]    Script Date: 06-10-2013 15:12:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Users](
	[userID] [int] IDENTITY(1,1) NOT NULL,
	[domainID] [int] NOT NULL,
	[roleID] [int] NOT NULL,
	[userName] [nvarchar](100) NOT NULL,
	[password] [nvarchar](100) NULL,
	[lastLoginTime] [nvarchar](50) NULL,
 CONSTRAINT [Users_PK] PRIMARY KEY NONCLUSTERED 
(
	[userID] ASC,
	[domainID] ASC,
	[roleID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Users]  WITH CHECK ADD  CONSTRAINT [Users_Domain_FK] FOREIGN KEY([domainID])
REFERENCES [dbo].[domains] ([domainID])

ALTER TABLE [dbo].[Users]  WITH CHECK ADD  CONSTRAINT [Users_Role_FK] FOREIGN KEY([roleID])
REFERENCES [dbo].[domains] ([domainID])
GO

ALTER TABLE [dbo].[Users] CHECK CONSTRAINT [Users_Domain_FK]
ALTER TABLE [dbo].[Users] CHECK CONSTRAINT [Users_Role_FK]
GO

ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [DF_Users_roleID]  DEFAULT ((5)) FOR [roleID]
GO


