USE [psHandler]
GO

/****** Object:  Table [dbo].[domains]    Script Date: 16-09-2013 17:05:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[domains](
	[domainID] [int] IDENTITY(1,1) NOT NULL,
	[domainName] [nvarchar](100) NOT NULL,
	[domainFQDN] [nvarchar](100) NOT NULL,
 CONSTRAINT [Domain_PK] PRIMARY KEY NONCLUSTERED 
(
	[domainID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


