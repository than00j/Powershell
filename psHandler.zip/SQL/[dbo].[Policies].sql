USE [psHandlerInv]
GO

/****** Object:  Table [dbo].[Policies]    Script Date: 06-10-2013 22:35:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Policies](
	[policyID] [int] IDENTITY(1,1) NOT NULL,
	[roleID] [int] NOT NULL,
	[policyName] [nvarchar](100) NOT NULL,
	[policyObject] [varchar](10) NOT NULL,
	[policyDomain] [int] NOT NULL,
	[policySite] [int] NOT NULL,
	[policyGUID] [nvarchar](100) NULL,
	[policyPackage] [nvarchar](500) NOT NULL,
	[policyArgs] [nvarchar](max) NULL,
	[policyAction] [nvarchar](20) NOT NULL,
	[policyAppliesTo] [nvarchar](max) NOT NULL,
	[TargetOS] [nvarchar](10) NOT NULL,
	[TargetBitness] [nvarchar](10) NOT NULL,
	[policyCreatedBy] [int] NOT NULL,
	[policyCreatedDate] [nvarchar](20) NOT NULL,
	[policyModifiedBy] [int] NOT NULL,
	[policyModifiedDate] [nvarchar](20) NOT NULL,
	[comments] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_Policies_1] PRIMARY KEY CLUSTERED 
(
	[policyName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Policies] ADD  CONSTRAINT [DF_Users_TargetOS]  DEFAULT ('Any') FOR [TargetOS]
GO

ALTER TABLE [dbo].[Policies] ADD  CONSTRAINT [DF_Users_TargetBitness]  DEFAULT ('Any') FOR [TargetBitness]
GO


