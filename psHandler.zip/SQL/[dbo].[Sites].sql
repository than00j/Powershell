USE [psHandlerInv]
GO

/****** Object:  Table [dbo].[Sites]    Script Date: 06-10-2013 19:41:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Sites](
	[siteID] [int] IDENTITY(1,1) NOT NULL,
	[domainID] [int] NOT NULL,
	[siteName] [nvarchar](10) NOT NULL,
 CONSTRAINT [PK_sites] PRIMARY KEY CLUSTERED 
(
	[siteName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


