USE [psHandlerInv]
GO
/****** Object:  Table [dbo].[Machines]    Script Date: 10/16/2013 17:21:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Machines](
	[machineID] [int] IDENTITY(1,1) NOT NULL,
	[domainID] [int] NOT NULL,
	[hostname] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[dnsname] [nvarchar](300) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[macAddress] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[ipAddress] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[osname] [nvarchar](300) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[osarch] [nvarchar](5) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[windir] [nvarchar](300) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[sysdir] [nvarchar](300) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ram] [numeric](38, 0) NOT NULL,
	[virtualMem] [numeric](38, 0) NOT NULL,
	[pageFile] [numeric](38, 0) NULL,
	[createdDate] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[lastModified] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
 CONSTRAINT [PK_Machines] PRIMARY KEY CLUSTERED 
(
	[hostname] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


/*
USE [psHandler]
GO

/****** Object:  Table [dbo].[Machines]    Script Date: 15-10-2013 18:01:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Machines](
	[machineID] [int] IDENTITY(1,1) NOT NULL,
	[serverID][int] NOT NULL,
	[domainID] [int] NOT NULL,
	[hostname] [nvarchar](100) NOT NULL,
	[dnsname] [nvarchar](300) NOT NULL,
	[macAddress] [nvarchar](200) NOT NULL,
	[ipAddress] [nvarchar](200) NOT NULL,
	[osname] [nvarchar](300) NOT NULL,
	[osarch] [nvarchar](5) NOT NULL,
	[windir] [nvarchar](300) NULL,
	[sysdir] [nvarchar](300) NULL,
	[ram] [numeric](38, 0) NOT NULL,
	[virtualMem] [numeric](38, 0) NOT NULL,
	[pageFile] [numeric](38, 0) NULL,
	[createdDate] [nvarchar](50) NOT NULL,
	[lastModified] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_Machines] PRIMARY KEY CLUSTERED 
(
	[hostname] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
*/

