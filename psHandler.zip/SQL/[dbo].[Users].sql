USE [psHandler]
GO

/****** Object:  Table [dbo].[Users]    Script Date: 06-10-2013 18:10:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Users](
	[userID] [int] IDENTITY(1,1) NOT NULL,
	[domainID] [int] NOT NULL,
	[roleID] [int] NOT NULL,
	[siteID] [int] NOT NULL,
	[userName] [nvarchar](100) NOT NULL,
	[password] [nvarchar](100) NULL,
	[lastLoginTime] [nvarchar](50) NULL,
 CONSTRAINT [PK_Users_1] PRIMARY KEY CLUSTERED 
(
	[userName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [DF_Users_roleID]  DEFAULT ((5)) FOR [roleID]
GO



