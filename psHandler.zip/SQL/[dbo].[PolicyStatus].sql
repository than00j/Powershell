USE [psHandlerInv]
GO
/****** Object:  Table [dbo].[PolicyStatus]    Script Date: 10/21/2013 15:49:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PolicyStatus](
	[policyName] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[policyObject] [nvarchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[objectID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[hostdnsname] [nvarchar](300) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[policyApplied] [nchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[policyComments] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[policyAppliedON] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]


/*
USE [psHandlerInv]
GO
/****** Object:  Table [dbo].[PolicyStatus]    Script Date: 10/16/2013 15:42:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PolicyStatus](
	[policyName] [nvarchar](100) NOT NULL,
	[policyObject] [nvarchar](10) NOT NULL,
	[objectID] [nvarchar](100) NOT NULL,
	[policyApplied] [nchar](10) NOT NULL,
	[policyComments] [nvarchar](max) NULL,
	[policyAppliedON] [nvarchar](50) NOT NULL)*/

/* OLD
USE [psHandler]
GO

/****** Object:  Table [dbo].[PolicyStatus]    Script Date: 06-10-2013 18:10:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[PolicyStatus](
	[pID] [int] IDENTITY(1,1) NOT NULL,
	[policyName] [nvarchar](100) NOT NULL,
	[policyObject] [nvarchar](10) NOT NULL,
	[objectID] [int] NOT NULL,
	[policyApplied] [nchar](10) NOT NULL,
	[policyComments] [nvarchar](max) NULL,
	[policyApplyON] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_PolicyStatus_1] PRIMARY KEY CLUSTERED 
(
	[policyName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

*/


