USE [psHandlerInv]
GO
/****** Object:  Table [dbo].[Admins]    Script Date: 10/17/2013 08:10:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Admins](
	[userID] [int] IDENTITY(1,1) NOT NULL,
	[domainID] [int] NOT NULL,
	[roleID] [int] NOT NULL CONSTRAINT [DF_Admins_roleID]  DEFAULT ((5)),
	[siteID] [int] NOT NULL,
	[userName] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[password] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[lastLoginTime] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK_Admins] PRIMARY KEY CLUSTERED 
(
	[userName] ASC
)WITH (IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]