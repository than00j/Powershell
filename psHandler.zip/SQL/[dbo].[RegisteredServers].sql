USE [psHandlerInv]
GO

/****** Object:  Table [dbo].[RegisteredServers]    Script Date: 06-10-2013 19:01:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RegisteredServers](
	[serverID] [int] IDENTITY(1,1) NOT NULL,
	[domainID] [int] NOT NULL,
	[serverName] [nvarchar](100) NOT NULL,
	[serverFQDN] [nvarchar](300) NULL,
	[ipAddress] [nvarchar](200) NOT NULL,
	[serverStatus] [nchar](10) NULL,
	[createdBy] [int] NOT NULL,
	[createdDate] [nvarchar](50) NOT NULL,
	[ModifiedBy] [int] NOT NULL,
	[lastUpdated] [nvarchar](50) NOT NULL,
) ON [PRIMARY]

GO


