USE [psHandlerInv]
GO

/****** Object:  Table [dbo].[Visitors]    Script Date: 06-10-2013 18:11:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Visitors](
	[userName] [nvarchar](100) NOT NULL,
	[lastLoginTime] [nvarchar](50) NOT NULL
) ON [PRIMARY]

GO


