# ==============================================================================================
# NAME    : Logon.ps1  
# AUTHOR  : Benjamin MARY 
# DATE    : 06/11/2015
# COMMENT : Logon Script GUI powershell with tasks list, animation et transparency
#           For animated gif it's here http://ajaxload.info/ with IE ! with Firefox gif is KO
# ==============================================================================================

Function isLoaded {
    Param( [String]$fName )
    
    $Loaded = $Fase
    [System.Windows.Forms.Application]::OpenForms | %{ If ( $_.Name -eq $fName ) { $Loaded = $True } }
    Return $Loaded
    }

Function add-OK {
    Param( [Boolean]$TskOK, [Boolean]$ShowWait )

    #region OkBox add OK/KO picture to form
    $Script:SyncHash.OkBox = new-object Windows.Forms.PictureBox
    $Script:SyncHash.OkBox.Width = $Script:SyncHash.WaitBox.Size.Width
    $Script:SyncHash.OkBox.Height = $Script:SyncHash.WaitBox.Size.Height
    If ( $TskOK ) { $Script:SyncHash.OkBox.Image = $Script:SyncHash.picOK }
    Else { $Script:SyncHash.OkBox.Image = $Script:SyncHash.picKO }
    $Script:SyncHash.OkBox.Name = "TaskOK"
    $Script:SyncHash.GroupBox.Invoke( [Action]{ $Script:SyncHash.GroupBox.Controls.add($Script:SyncHash.OkBox) } )
    $Script:SyncHash.OkBox.Location = $Script:SyncHash.WaitBox.Location # Left, Top
    $Script:SyncHash.OkBox.Visible = $True
	#endregion 

    # Move down WaitBox for next task
    If ( $ShowWait ) { $Script:SyncHash.WaitBox.Location = New-Object System.Drawing.Size( 10, ($Script:SyncHash.WaitBox.Top + 20) ) }
    Else { $Script:SyncHash.WaitBox.Visible = $False } 
    $Script:SyncHash.GroupBox.Refresh()
    #region if more than 4 Tasks, move UP labels's & pics's tasks
    $CountOK = ($Script:SyncHash.GroupBox.Controls | ?{ $_.Name -match "^TaskOK" }).Count
 
    If ( $TaskCount -gt 4) {
        If ( ($CountOK -ge 3) -and ($CountOK -lt ($TaskCount - 1 )) ) {             
            $Script:SyncHash.GroupBox.Controls | ?{ $_.Name -match "^Task*" } | %{ 
                $_.Location = New-Object System.Drawing.Size( $_.Left, ($_.Top - 20) ) 
                If ( ($_.Top -lt 10) -or ($_.top -gt 100) ) { $_.Visible = $False } # Hide control because out of GroupBox view
                Else { $_.Visible = $True } # Show control because inside of GroupBox view
                }
            # Move UP also Waitbox
            $Script:SyncHash.WaitBox.Location = New-Object System.Drawing.Size( 10, ($Script:SyncHash.WaitBox.Top - 20) )
            }
        }    
    #endregion 

    # Refresh form
    $Script:SyncHash.GroupBox.Refresh()
    }

# ##### Main Script #####
    
# Need to load assembly in main Script too
[Void] [reflection.assembly]::loadwithpartialname("System.Windows.Forms")
[Void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")

$Script:SyncHash = [hashtable]::Synchronized(@{})
$nRunSpace = [RunSpaceFactory]::CreateRunspace()
$nRunSpace.ApartmentState = "STA"
$nRunSpace.Threadoptions = "ReuseThread"
$nRunSpace.Open()
$nRunSpace.SessionStateProxy.SetVariable("SyncHash", $Script:SyncHash)

# Get current Script Path
$Script:SyncHash.ScriptRoot = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition

$psCMD = [PowerShell]::Create().AddScript({
    
    Add-Type -AssemblyName System.Drawing

    # enable rich visual styles in PowerShell
    [System.Windows.Forms.Application]::EnableVisualStyles()

    #region Import Assemblies to do before [System.Windows.Forms....]
    [reflection.assembly]::loadwithpartialname("System.Windows.Forms") | Out-Null
    [reflection.assembly]::loadwithpartialname("System.Drawing") | Out-Null
    #endregion

    #region Images / Gif / Icon
    $Script:SyncHash.picOK = [System.Drawing.Image]::FromFile("$($Script:SyncHash.ScriptRoot)\Images\OK.png")
    $Script:SyncHash.picKO = [System.Drawing.Image]::FromFile("$($Script:SyncHash.ScriptRoot)\Images\KO.png")
    $Script:SyncHash.Wait  = [System.Drawing.Image]::FromFile("$($Script:SyncHash.ScriptRoot)\Images\WaitSnakeGrey.gif")
    $Script:SyncHash.Logo  = [System.Drawing.Image]::Fromfile("$($Script:SyncHash.ScriptRoot)\Images\MyLogon.png")
    $Script:SyncHash.Fond  = [System.Drawing.Image]::Fromfile("$($Script:SyncHash.ScriptRoot)\Images\Fond.png")
    $Script:SyncHash.Icon  = [System.Drawing.Icon]::ExtractAssociatedIcon("$($Script:SyncHash.ScriptRoot)\Ico\MyLogon.ico")
    #endregion 
 
    #region Form Objects
    $Script:SyncHash.InitialFormWindowState = New-Object System.Windows.Forms.FormWindowState
    $Script:SyncHash.Form = New-Object System.Windows.Forms.Form
    $Script:SyncHash.Form.Size = New-Object System.Drawing.Size(547, 205) # Width, Height
    $Script:SyncHash.Form.ControlBox = $False
    $Script:SyncHash.Form.Name = "Logon"
    $Script:SyncHash.Form.FormBorderStyle = "None"
    $Script:SyncHash.Form.BackColor = "White"
    #region to manage transparency
    $Script:SyncHash.Form.BackColor = "Magenta"
    $Script:SyncHash.Form.BackgroundImage = $Script:SyncHash.Fond
    $Script:SyncHash.Form.BackgroundImageLayout = 0
    $Script:SyncHash.Form.TransparencyKey = "Magenta"
    #endregion
    $Script:SyncHash.Form.Text = "LogonScript - Optimisation..."
    $Script:SyncHash.Form.StartPosition = "CenterScreen"
    $Script:SyncHash.Form.Icon = $Script:SyncHash.Icon
    #endregion

    #region PictureBox
    $Script:SyncHash.LogoBox = new-object Windows.Forms.PictureBox
    $Script:SyncHash.LogoBox.Location = New-Object System.Drawing.Size(0, 0)
    $Script:SyncHash.LogoBox.Width = $Script:SyncHash.Logo.Size.Width
    $Script:SyncHash.LogoBox.Height = $Script:SyncHash.Logo.Size.Height
    $Script:SyncHash.LogoBox.Image = $Script:SyncHash.Logo
    $Script:SyncHash.LogoBox.Visible = $True
    $Script:SyncHash.form.controls.add($Script:SyncHash.LogoBox)
    #endregion

    #region GoupBox
    $Script:SyncHash.GroupBox = New-Object System.Windows.Forms.GroupBox
    $Script:SyncHash.GroupBox.Text = "Tasks : " 
    $Script:SyncHash.GroupBox.Name = "GpBox"
    $Script:SyncHash.GroupBox.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#2686B5')
    $Script:SyncHash.GroupBox.BackColor = "White"
    $Script:SyncHash.GroupBox.Size = New-Object System.Drawing.Size(500, 105) # Width, Height
    $Script:SyncHash.GroupBox.Location = New-Object System.Drawing.Size(37, 70) # Left, Top
    $Script:SyncHash.GroupBox.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $Script:SyncHash.Form.Controls.Add($Script:SyncHash.GroupBox)
    #endregion

    #region WaitBox
    $Script:SyncHash.WaitBox = new-object Windows.Forms.PictureBox
    $Script:SyncHash.WaitBox.Location = New-Object System.Drawing.Size(10, 20) # Left, Top
    $Script:SyncHash.WaitBox.Name = "WaitBox"
    $Script:SyncHash.WaitBox.Width = $Script:SyncHash.Wait.Size.Width
    $Script:SyncHash.WaitBox.Height = $Script:SyncHash.Wait.Size.Height
    $Script:SyncHash.WaitBox.Image = $Script:SyncHash.Wait
    $Script:SyncHash.WaitBox.Visible = $True
    $Script:SyncHash.GroupBox.controls.add($Script:SyncHash.WaitBox)
    #endregion

    #region Set controls for all script's tasks ###########################
    $Top = 21
    Import-Csv "$($Script:SyncHash.ScriptRoot)\Tasks.csv" -Delimiter ";" | %{
        $Script:SyncHash.LblTask = new-object Windows.Forms.Label
        $Script:SyncHash.LblTask.Text = $_.TaskName
        $Script:SyncHash.LblTask.Location = New-Object System.Drawing.Size(40, $Top) # Left, Top
        $Script:SyncHash.LblTask.Size = New-Object System.Drawing.Size(300, 20) # Width, Height
        If ( $Top -gt 100 ) { $Script:SyncHash.LblTask.Visible = $False } # Hide it if out of GroupBox Height
        $Script:SyncHash.LblTask.Name = "Task"
        $Script:SyncHash.LblTask.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#2686B5')
        $Script:SyncHash.GroupBox.controls.add($Script:SyncHash.LblTask)
        $Top = $Top + 20
        }
    #endregion ############################################################

    $Script:SyncHash.InitialFormWindowState = $Script:SyncHash.Form.WindowsState
    $Script:SyncHash.Form.Add_Load($Script:SyncHash.OnLoadForm_StateCorrection)
    $Script:SyncHash.Form.ShowDialog() | Out-Null

    })

$psCMD.RunSpace = $nRunSpace
$Data = $psCMD.BeginInvoke()

While ( !( isloaded "Logon" ) ) { Sleep -milliseconds 100 }

# Get task count
$TaskCount = ($Script:SyncHash.GroupBox.Controls | ?{ $_.Name -eq "Task" }).Count

# Simulate big script
1..120 | %{
    #Write-Host $_
    If ( $_ -eq 20 ) { Add-OK $True $True }
    If ( $_ -eq 40 ) { Add-OK $False $True }
    If ( $_ -eq 60 ) { Add-OK $True $True }
    If ( $_ -eq 80 ) { Add-OK $False $True }
    If ( $_ -eq 100 ) { Add-OK $True $True }
    If ( $_ -eq 120 ) { Add-OK $True $False }
    Sleep -milliseconds 100
    }

Start-Sleep -Seconds 1
$Script:SyncHash.Form.Close()